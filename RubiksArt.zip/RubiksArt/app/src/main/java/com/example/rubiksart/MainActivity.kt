package com.example.rubiksart

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.rubiksart.program.AStar
import java.io.Serializable

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        var result: Array<Array<String?>> = arrayOf(
            arrayOf("B","R","Y"),
            arrayOf("R","R","Y"),
            arrayOf("G","G","Y"))

        val start = findViewById<Button>(R.id.start)
        start.setOnClickListener{
            val solver = AStar(result)
            val picture = solver.Search()
            val intent = Intent(this, StartActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("picture", picture as Serializable)
            intent.putExtras(bundle)
            startActivity(intent)
        }
    }
}
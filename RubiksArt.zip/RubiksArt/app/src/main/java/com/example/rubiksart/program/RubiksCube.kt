package com.example.rubiksart.program

class RubiksCube : Comparable<RubiksCube>
{
    private val n: Int = 3
    var presentFront: Array<Array<String>>
    var presentBack: Array<Array<String>>
    var presentUp: Array<Array<String>>
    var presentDown: Array<Array<String>>
    var presentRight: Array<Array<String>>
    var presentLeft: Array<Array<String>>
    private val frontResult: Array<Array<String?>>

    var Parent:RubiksCube? = null //батьківський об'єкт
    var action: String? = null

    constructor(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>, result: Array<Array<String?>>) {
        presentFront = front.clone()
        presentBack = back.clone()
        presentUp = up.clone()
        presentDown = down.clone()
        presentRight = right.clone()
        presentLeft = left.clone()
        frontResult = result.clone()
    }

    constructor(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>, result: Array<Array<String?>>, act: String, parent: RubiksCube) {
        presentFront = front.clone()
        presentBack = back.clone()
        presentUp = up.clone()
        presentDown = down.clone()
        presentRight = right.clone()
        presentLeft = left.clone()
        frontResult = result.clone()
        action = act
        Parent = parent
    }

    override fun compareTo(other: RubiksCube):Int {
        val presentHeuristic: Int = heuristicFunc();
        val neighboringHeuristic: Int = other.heuristicFunc();
        return presentHeuristic - neighboringHeuristic;
    }

    fun heuristicFunc(): Int {
        var numPositions = 0
        for (i in 0..2) {
            for (j in 0..2) {
                if (presentFront[i][j] == frontResult[i][j])
                    numPositions++
            }
        }
        return numPositions
    }

    fun getChild(variation: Int): RubiksCube {
        val newFront: Array<Array<String>> = Copy(presentFront)
        val newBack: Array<Array<String>> = Copy(presentBack)
        val newUp: Array<Array<String>> = Copy(presentUp)
        val newDown: Array<Array<String>> = Copy(presentDown)
        val newRight: Array<Array<String>> = Copy(presentRight)
        val newLeft: Array<Array<String>> = Copy(presentLeft)

        var act = ""

        when (variation) {
            1 -> {
                UpRight(newFront, newBack, newDown, newRight, newLeft)
                RotateAntiClockwise(newUp)
                act = "UR"
            }
            2 -> {
                UpLeft(newFront, newBack, newDown, newRight, newLeft)
                RotateClockwise(newUp)
                act = "UL"
            }
            3 -> {
                DownRight(newFront, newBack, newUp, newRight, newLeft)
                RotateClockwise(newDown)
                act = "DR"
            }
            4 -> {
                DownLeft(newFront, newBack, newUp, newRight, newLeft)
                RotateAntiClockwise(newDown)
                act = "DL"
            }
            5 -> {
                RightUp(newFront, newBack, newUp, newDown, newLeft)
                RotateClockwise(newRight)
                act = "RU"
            }
            6 -> {
                RightDown(newFront, newBack, newUp, newDown, newLeft)
                RotateAntiClockwise(newRight)
                act = "RD"
            }
            7 -> {
                LeftUp(newFront, newBack, newUp, newDown, newRight)
                RotateAntiClockwise(newLeft)
                act = "LU"
            }
            8 -> {
                LeftDown(newFront, newBack, newUp, newDown, newRight)
                RotateClockwise(newLeft)
                act = "LD"
            }
        }
        return RubiksCube(newFront, newBack, newUp, newDown, newRight, newLeft, frontResult, act, this)
    }

    fun Copy(state: Array<Array<String>>): Array<Array<String>> {
        val m = Array(n) { Array(n) { "" } }
        for (i in 0..2) {
            for (j in 0..2) {
                m[i][j] = state[i][j]
            }
        }
        return m
    }

    fun UpRight(front: Array<Array<String>>, back: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>) {
        for (j in 0..2) {
            val temp: String = front[0][j]
            front[0][j] = left[0][j]
            left[0][j] = back[0][j]
            back[0][j] = right[0][j]
            right[0][j] = temp
        }
    }

    fun UpLeft(front: Array<Array<String>>, back: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>) {
        for (j in 0..2) {
            val temp: String = front[0][j]
            front[0][j] = right[0][j]
            right[0][j] = back[0][j]
            back[0][j] = left[0][j]
            left[0][j] = temp
        }
    }

    fun DownRight(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>)
    {
        for (j in 0..2) {
            val temp: String = front[2][j]
            front[2][j] = left[2][j]
            left[2][j] = back[2][j]
            back[2][j] = right[2][j]
            right[2][j] = temp
        }
    }

    fun DownLeft(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, right: Array<Array<String>>, left: Array<Array<String>>)
    {
        for (j in 0..2) {
            val temp: String = front[2][j]
            front[2][j] = right[2][j]
            right[2][j] = back[2][j]
            back[2][j] = left[2][j]
            left[2][j] = temp
        }
    }

    fun RightUp(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, left: Array<Array<String>>)
    {
        var k = 2
        for (i in 0..2) {
            val temp: String = front[i][2]
            front[i][2] = down[i][2]
            down[i][2] = back[k][0]
            back[k][0] = up[i][2]
            up[i][2] = temp
            k--
        }
    }

    fun RightDown(front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, left: Array<Array<String>>)
    {
        var k = 2
        for (i in 0..2) {
            val temp: String = front[i][2]
            front[i][2] = up[i][2]
            up[i][2] = back[k][0]
            back[k][0] = down[i][2]
            down[i][2] = temp
            k--
        }
    }

    fun LeftUp (front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>) {
        var k = 2
        for (i in 0..2) {
            val temp: String = front[i][0]
            front[i][0] = down[i][0]
            down[i][0] = back[k][2]
            back[k][2] = up[i][0]
            up[i][0] = temp
            k--
        }
    }

    fun LeftDown (front: Array<Array<String>>, back: Array<Array<String>>, up: Array<Array<String>>, down: Array<Array<String>>, right: Array<Array<String>>)
    {
        var k = 2
        for (i in 0..2) {
            val temp: String = front[i][0]
            front[i][0] = up[i][0]
            up[i][0] = back[k][2]
            back[k][2] = down[i][0]
            down[i][0] = temp
            k--
        }
    }

    fun RotateClockwise(m: Array<Array<String>>)
    {
        val result = Array(n){Array(n){""} }
        for (i in 0..2) {
            for (j in 0..2) {
                result[i][j] = m[n - j - 1][i]
            }
        }
        for (i in 0..2) {
            for (j in 0..2) {
                m[i][j] = result[i][j]
            }
        }
    }

    fun RotateAntiClockwise(m: Array<Array<String>>)
    {
        val result = Array(n){Array(n){""} }
        for (i in 0..2) {
            for (j in 0..2) {
                result[i][j] = m[j][n - i - 1]
            }
        }
        for (i in 0..2) {
            for (j in 0..2) {
                m[i][j] = result[i][j]
            }
        }
    }

    fun Path (l:Int, ans: Answer){
        Parent?.Path(l+1, ans)
        ans.answer.add(presentFront)
        ans.action.add(action.toString())
    }
}